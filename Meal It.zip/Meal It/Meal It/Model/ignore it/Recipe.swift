//
//  Recipe.swift
//  Meal It
//
//  Created by Mamadou Diallo on 24/04/2021.
//

import Foundation


struct Recipe: Codable, Identifiable {
    let id: String
    let image: String
    let ingredients : String
    let steps: String
    let title:String
    let isRecommended : Bool
    
}
