//
//  Favorite.swift
//  Meal
//
//  Created by Mamadou Diallo on 02/05/2021.
//

import Foundation


struct Favorite: Codable, Identifiable {
    let id: String
    let smoothieID: String
    let Title: String
    let Image: String
  
    
}
