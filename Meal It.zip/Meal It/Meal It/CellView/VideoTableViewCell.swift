//
//  VideoTableViewCell.swift
//  Meal It
//
//  Created by Mamadou Diallo on 04/05/2021.
//

import UIKit

class VideoTableViewCell: UITableViewCell {

    @IBOutlet weak var smoothieImage: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var time: UILabel!
    
}
