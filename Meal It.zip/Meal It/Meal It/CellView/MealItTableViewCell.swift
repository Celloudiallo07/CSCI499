//
//  MealTableViewCell.swift
//  Meal It
//
//  Created by Mamadou Diallo on 04/05/2021.
//

import UIKit

class MealItTableViewCell: UITableViewCell {

    @IBOutlet weak var Title: UILabel!
    @IBOutlet weak var smoothieImage: Custom_ImageView!
    
    
  

}
