//
//  RecommendationCollectionViewCell.swift
//  Meal It
//
//  Created Mamadou Diallo on 04/05/2021.
//

import UIKit

class RecommendationCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var Title: UILabel!
    @IBOutlet weak var smoothieImage: UIImageView!
}
