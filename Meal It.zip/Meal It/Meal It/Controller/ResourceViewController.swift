//
//  ResourceViewController.swift
//  Meal It
//
//  Created by Mamadou Diallo on 05/05/2021.
//

import UIKit

class ResourceViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func backButtonAction(){
        self.navigationController?.popViewController(animated: true)
    }

}
