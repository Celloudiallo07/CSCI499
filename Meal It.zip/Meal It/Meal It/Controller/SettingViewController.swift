//
//  SettingViewController.swift
//  Meal It
//
//  Created by Mamadou Diallo on 05/05/2021.
//

import UIKit

class SettingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        tabBarController?.tabBar.isHidden = true
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func onClickTabBar(_ sender: UIButton){
        
        let tag = sender.tag
        
        if tag == 1{
         
            tabBarController?.selectedIndex = 0
        }
        
        else if tag == 2{
            tabBarController?.selectedIndex = 1
        }
        
        else if tag == 3{
            tabBarController?.selectedIndex = 2
        }
        
        else if tag == 4{
            tabBarController?.selectedIndex = 3
        }
        
    }
    
    

    @IBAction func onClickAbout(_ sender: UIButton){
        performSegue(withIdentifier: "About", sender: nil)
    }
   
    @IBAction func onClickResource(_ sender: UIButton){
        performSegue(withIdentifier: "Resource", sender: nil)
    }
    
    @IBAction func onClickPrivacy(_ sender: UIButton){
        performSegue(withIdentifier: "Privacy", sender: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
