//
//  ViewController.swift
//  Meal It
//
//  Created by Mamadou Diallo on 05/05/2021.
//

import UIKit

class ViewController: UIViewController {

    
    
    
    @IBOutlet weak var logoTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var ageTF: UITextField!
    @IBOutlet weak var favTF: UITextField!
    
    
    
    @IBOutlet weak var blurView: UIVisualEffectView!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        blurView.layer.cornerRadius = 25
        blurView.layer.masksToBounds = true
        
        logoTopConstraint.constant = 120

        
       let value = UserDefaults.standard.dictionary(forKey: "PERSONAL")
        
        nameTF.text = value?["name"] as? String
        ageTF.text = value?["age"]  as? String
        favTF.text = value?["fav"]  as? String
       
        
    }

    @IBAction func continueButtonAction(){
       
        let dict  = ["name": nameTF.text,
                     "age":ageTF.text,
                     "fav":favTF.text]
        
        UserDefaults.standard.set(dict, forKey: "PERSONAL")
    }
    
    
}

